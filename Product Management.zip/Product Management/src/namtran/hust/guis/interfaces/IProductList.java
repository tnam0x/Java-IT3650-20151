package namtran.hust.guis.interfaces;

import java.util.ArrayList;

import namtran.hust.guis.model.Product;

public interface IProductList {
	public ArrayList<Product> getProduct();
}
