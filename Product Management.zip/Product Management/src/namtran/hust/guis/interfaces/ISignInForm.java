package namtran.hust.guis.interfaces;

public interface ISignInForm {
	public String getUserNameOnSignInForm();

	public String getPasswordOnSignInForm();
	
	//public void setSignInButtonActionListener(ActionListener action);
	
}
