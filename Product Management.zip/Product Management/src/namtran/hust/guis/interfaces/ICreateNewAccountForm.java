package namtran.hust.guis.interfaces;

public interface ICreateNewAccountForm {
	public String getNewUserName();

	public String getNewPassword();

	// public void setActionListenerOnCreateButton(ActionListener action);
}
