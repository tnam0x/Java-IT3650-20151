package namtran.hust.guis.interfaces;

public interface IProduct {
	public void setProductID(String productID);

	public String getProductID();

	public void setProductName(String productName);

	public String getProductName();

	public void setAmount(int amount);

	public int getAmount();
}
