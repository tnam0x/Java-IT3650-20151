package namtran.hust.guis.interfaces;

public interface IAccountList {
	public void addAccount(IAccount iAccount);

	public int check(String userName, String password);
}
