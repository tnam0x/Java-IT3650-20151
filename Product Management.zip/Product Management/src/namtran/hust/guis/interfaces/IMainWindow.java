package namtran.hust.guis.interfaces;

public interface IMainWindow {
//	public void setSignOutActionListener(ActionListener action);

//	public void setCreateAccountActionListener(ActionListener action);

	public Void addCreateAccountMenu();
}
